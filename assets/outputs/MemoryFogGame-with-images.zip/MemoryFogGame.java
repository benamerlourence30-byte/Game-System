import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.imageio.ImageIO;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.AudioSystem;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.geom.RoundRectangle2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.AWTEventListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URISyntaxException;
import java.util.*;
import java.util.List;


public class MemoryFogGame {
    private static final int MAX_LEVEL = 50;
    private static final int VARIANTS_PER_IMAGE = 9;
    private static final Color BACKGROUND = new Color(18, 19, 39);
    private static final Color PANEL = new Color(35, 37, 76);
    private static final Color ACCENT = new Color(255, 201, 54);
    private static final Color GOLD = new Color(255, 201, 54);
    private static final Color TEAL = new Color(45, 226, 193);
    private static final Color MAGENTA = new Color(219, 31, 112);
    private static final Color MUTED = new Color(184, 190, 219);
    private static final Color CARD_PURPLE = new Color(91, 61, 207);
    private static final String[] CARD_IMAGES = {
        "blue-face.png", "yellow-face.png", "dress-collage.png",
        "monkey.png", "jun.jpg", "tandang-nick.jpg"
    };
    private static final String[] THEME_NAMES = {
        "MIDNIGHT", "TIDAL", "VIOLET", "FOREST", "SUNSET",
        "GLACIER", "EMBER", "DREAM", "COSMOS", "AURORA"
    };
    private static final Color[] BOARD_THEMES = {
        new Color(35, 37, 76), new Color(28, 57, 75), new Color(53, 42, 91),
        new Color(28, 75, 68), new Color(90, 37, 67), new Color(35, 64, 88),
        new Color(92, 48, 43), new Color(58, 43, 89), new Color(31, 46, 86),
        new Color(29, 77, 76)
    };
    private static final String[] CARD_BACK_NAMES = {"Level theme", "Amethyst", "Lagoon", "Rose gold"};
    private static final Color[] CARD_BACK_SKINS = {
        new Color(73, 99, 151), new Color(117, 77, 165),
        new Color(43, 139, 151), new Color(173, 91, 111)
    };
    private static final Color[] THEME_CARD_BACKS = {
        new Color(73, 99, 151), new Color(45, 116, 140), new Color(104, 78, 151),
        new Color(58, 119, 91), new Color(157, 87, 78), new Color(68, 122, 161),
        new Color(164, 91, 60), new Color(112, 82, 155), new Color(65, 88, 166),
        new Color(46, 137, 129)
    };
    private static final int[] CARD_BACK_PRICES = {0, 150, 200, 250};
    private static final File SAVE_FILE = new File(System.getProperty("user.dir"), "memoryfog-save.properties");
    private static final Map<String, BufferedImage> IMAGE_CACHE = new HashMap<>();

    /** A card button that can flip, spin, and fade using Swing's repaint loop. */
    private static class AnimatedCardButton extends JButton {
        private double flipProgress = 1.0;
        private double matchProgress = -1.0;
        private BufferedImage cardImage;
        private String variantLabel = "A";
        private boolean hintVisible;
        private boolean xrayVisible;
        private boolean frozenVisible;
        private double xrayProgress = 1.0;

        AnimatedCardButton() { super("?"); }

        void showImage(BufferedImage image, String variant) {
            cardImage = image;
            variantLabel = variant;
            xrayVisible = false;
            frozenVisible = false;
            putClientProperty("imageName", null);
            setText(image == null ? "?" : "");
            repaint();
        }

        void showImage(BufferedImage image, String imageName, String variant) {
            cardImage = image;
            variantLabel = variant;
            xrayVisible = false;
            frozenVisible = false;
            putClientProperty("imageName", imageName);
            setText(image == null ? "?" : "");
            repaint();
        }

        void showXray(BufferedImage image, String imageName, String variant) {
            cardImage = image;
            variantLabel = variant;
            xrayVisible = true;
            putClientProperty("imageName", imageName);
            setText(image == null ? "?" : "");
            xrayProgress = 0.0;
            runAnimation(420, progress -> {
                xrayProgress = progress;
                repaint();
            }, null);
        }

        void setFrozenVisible(boolean visible) { frozenVisible = visible; repaint(); }

        void setHintVisible(boolean visible) {
            hintVisible = visible;
            repaint();
        }

        boolean isXrayVisible() { return xrayVisible; }

        void playFlip() {
            flipProgress = 0.0;
            runAnimation(220, progress -> {
                flipProgress = progress;
                repaint();
            }, null);
        }

        void playMatch(Runnable finished) {
            matchProgress = 0.0;
            runAnimation(650, progress -> {
                matchProgress = progress;
                repaint();
            }, finished);
        }

        private void runAnimation(int duration, java.util.function.DoubleConsumer update, Runnable finished) {
            final long started = System.nanoTime();
            javax.swing.Timer animation = new javax.swing.Timer(16, null);
            animation.addActionListener(event -> {
                double progress = Math.min(1.0, (System.nanoTime() - started) / (duration * 1_000_000.0));
                update.accept(progress);
                if (progress >= 1.0) {
                    animation.stop();
                    if (finished != null) finished.run();
                }
            });
            animation.start();
        }

        @Override protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();
            if (matchProgress >= 0.0) {
                double p = matchProgress;
                g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float)(1.0 - p)));
                g.rotate(Math.PI * 2.0 * p, w / 2.0, h / 2.0);
                double scale = 1.0 - 0.85 * p;
                g.translate(w * (1.0 - scale) / 2.0, h * (1.0 - scale) / 2.0);
                g.scale(scale, scale);
            } else if (flipProgress < 1.0) {
                double widthScale = Math.max(0.06, Math.abs(Math.cos(Math.PI * flipProgress)));
                g.translate(w * (1.0 - widthScale) / 2.0, 0);
                g.scale(widthScale, 1.0);
            }

            boolean faceDown = "?".equals(getText()) && !xrayVisible && !hintVisible;
            // Rounded squad-card frame inspired by the supplied purple, gold, and magenta design.
            g.setColor(new Color(6, 8, 25, 155));
            g.fillRoundRect(3, 6, w - 7, h - 9, 22, 22);
            g.setColor(new Color(31, 33, 70));
            g.fillRoundRect(2, 2, w - 7, h - 9, 22, 22);
            if (faceDown) {
                Shape oldClip = g.getClip();
                g.clip(new RoundRectangle2D.Float(7, 7, w - 17, h - 18, 16, 16));
                g.setColor(CARD_PURPLE.darker());
                g.fillRect(7, 7, w - 17, h - 18);
                g.setColor(new Color(20, 14, 75, 100));
                for (int x = -h; x < w + h; x += 24) g.fillPolygon(
                    new int[]{x, x + 12, x + h + 12, x + h},
                    new int[]{h, h, 0, 0}, 4);
                g.setClip(oldClip);
                g.setColor(MAGENTA);
                g.setStroke(new BasicStroke(3.5f));
                g.drawRoundRect(3, 3, w - 9, h - 12, 20, 20);
                g.setStroke(new BasicStroke(1f));
            } else {
                g.setPaint(new GradientPaint(0, 2, CARD_PURPLE, 0, h, new Color(48, 39, 112)));
                g.fillRoundRect(7, 7, w - 17, h - 18, 16, 16);
                if (cardImage != null) {
                    int ix = 8, iy = 8, iw = Math.max(1, w - 20), ih = Math.max(1, h - 20);
                    Shape oldClip = g.getClip();
                    g.clip(new RoundRectangle2D.Float(ix, iy, iw, ih, 15, 15));
                    double scale = Math.min((double) iw / cardImage.getWidth(), (double) ih / cardImage.getHeight());
                    if (!"dress-collage.png".equals(getClientProperty("imageName"))) {
                        scale = Math.max((double) iw / cardImage.getWidth(), (double) ih / cardImage.getHeight());
                    }
                    int dw = (int) (cardImage.getWidth() * scale);
                    int dh = (int) (cardImage.getHeight() * scale);
                    int dx = ix + (iw - dw) / 2;
                    int dy = iy + (ih - dh) / 2;
                    if (dh > ih) dy = iy + (int) ((ih - dh) * 0.38);
                    g.drawImage(cardImage, dx, dy, dw, dh, null);
                    g.setClip(oldClip);
                    g.setColor(new Color(255, 255, 255, 55));
                    g.drawRoundRect(ix, iy, iw, ih, 15, 15);
                    g.setColor(new Color(19, 27, 48, 205));
                    g.fillRoundRect(w - 28, 9, 17, 17, 8, 8);
                    g.setColor(Color.WHITE);
                    g.setFont(new Font("SansSerif", Font.BOLD, 10));
                    FontMetrics fm = g.getFontMetrics();
                    g.drawString(variantLabel, w - 28 + (17 - fm.stringWidth(variantLabel)) / 2, 21);
                } else {
                    g.setColor(new Color(255, 255, 255, 55));
                    g.fillRoundRect(8, 8, w - 20, 5, 5, 5);
                }
                g.setColor(GOLD);
                g.setStroke(new BasicStroke(3.5f));
                g.drawRoundRect(3, 3, w - 9, h - 12, 20, 20);
                g.setStroke(new BasicStroke(1f));
            }
            super.paintComponent(g);
            if (!faceDown && hintVisible) {
                g.setColor(new Color(255, 211, 83));
                g.fillOval(7, 7, 25, 25);
                g.setColor(new Color(40, 45, 65));
                g.setFont(new Font("SansSerif", Font.BOLD, 16));
                g.drawString("✦", 12, 25);
            }
            if (frozenVisible) {
                g.setColor(new Color(70, 210, 255, 75));
                g.fillRoundRect(7, 7, w - 17, h - 18, 16, 16);
                g.setColor(new Color(132, 239, 255, 230));
                g.setStroke(new BasicStroke(3f));
                g.drawRoundRect(4, 4, w - 11, h - 14, 18, 18);
                g.setFont(new Font("SansSerif", Font.BOLD, 18));
                g.drawString("❄", w - 25, 26);
                g.setStroke(new BasicStroke(1f));
            }
            if (!faceDown && xrayVisible) {
                int pulse = (int) (5 * (1.0 - xrayProgress));
                g.setColor(new Color(132, 239, 255, 210));
                g.setStroke(new BasicStroke(2.5f));
                g.drawOval(5 - pulse, 5 - pulse, 24 + pulse * 2, 24 + pulse * 2);
                g.drawLine(24, 24, 34, 34);
                g.setStroke(new BasicStroke(1f));
            }
            g.dispose();
        }
    }

    private final JFrame frame = new JFrame("Squad Flip: Who's Who?");
    private final JPanel root = new JPanel(new CardLayout());
    private final JPanel board = new JPanel();
    private final JLabel levelLabel = new JLabel();
    private final JLabel moneyLabel = new JLabel();
    private final JLabel timerLabel = new JLabel();
    private final JLabel statusLabel = new JLabel("Find every matching pair!");
    private final JLabel inventoryLabel = new JLabel();
    private final JLabel levelSelectCoinsLabel = new JLabel();
    private final JLabel mainMenuCoinsLabel = new JLabel();
    private final JButton homeButton = new JButton("← LEVELS");
    private final JButton shopButton = new JButton("🛒 Shop");
    private final JButton magnifyButton = new JButton("🔍 Magnify");
    private final JButton hintButton = new JButton("💡 Hint");
    private final JButton shieldButton = new JButton("🛡 Shield");
    private final JButton timerButton = new JButton("⏱ +1 second");
    private final java.util.List<Card> cards = new ArrayList<>();
    private final Random random = new Random();
    private final javax.swing.Timer clock;
    private Process levelAudioProcess;
    private File levelAudioRequestFile;
    private int levelAudioRequestId;
    private Process bonusAudioProcess;
    private File bonusAudioRequestFile;
    private int bonusAudioRequestId;
    private AudioClip uiClickAudio;
    private final JButton[] levelButtons = new JButton[MAX_LEVEL + 1];

    private int level = 1;
    private boolean gameCompleted = false;
    private int highestUnlockedLevel = 1;
    private int selectedCardBack = 0;
    private final boolean[] unlockedCardBacks = {true, false, false, false};
    private final int[] starsByLevel = new int[MAX_LEVEL + 1];
    private int coins = 0;
    private int secondsLeft = 300;
    private int levelTimeLimit = 300;
    private int wrongGuesses = 0;
    private int matchedPairs = 0;
    private int firstCard = -1;
    private int secondCard = -1;
    private int lockCount = 0;
    private int obstaclesRemaining = 0;
    private boolean obstacleActive = false;
    private Card frozenObstacleCard;
    private javax.swing.Timer obstacleTimer;
    private int lastLevelReward = 30;
    private int magnifiers = 0, hints = 0, shields = 0, timerBoosts = 0;
    private boolean shieldArmed = false;
    private boolean magnifierActive = false;
    private int magnifierSeconds = 0;
    private javax.swing.Timer magnifierTimer;
    private int boardRows;
    private int boardColumns;

    private static class Card {
        String face;
        String imageName;
        String variant;
        final AnimatedCardButton button = new AnimatedCardButton();
        boolean matched = false;
        boolean revealed = false;
        boolean frozen = false;
        Card(String face, String imageName, String variant) {
            setFace(face);
        }
        void setFace(String face) {
            this.face = face;
            String[] parts = face.split("\\|");
            imageName = parts[0];
            variant = parts[1];
        }
    }

    public MemoryFogGame() {
        clock = new javax.swing.Timer(1000, e -> tick());
        loadProgress();
        preloadLevelStartAudio();
        preloadBonusAudio();
        preloadUiClickAudio();
        buildWindow();
    }

    private void buildWindow() {
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(760, 580));
        frame.setSize(1000, 800);
        frame.setLocationRelativeTo(null);
        JPanel gameScreen = new JPanel(new BorderLayout(12, 12));
        gameScreen.setBackground(BACKGROUND);
        gameScreen.setBorder(new EmptyBorder(16, 18, 16, 18));

        JPanel header = new JPanel(new BorderLayout(10, 7));
        header.setOpaque(false);
        JLabel title = new JLabel("SQUAD FLIP: WHO'S WHO?");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 26));
        JPanel stats = new JPanel(new FlowLayout(FlowLayout.RIGHT, 16, 0));
        stats.setOpaque(false);
        for (JLabel label : new JLabel[]{levelLabel, moneyLabel, timerLabel}) {
            label.setForeground(Color.WHITE);
            label.setFont(new Font("SansSerif", Font.BOLD, 15));
            stats.add(label);
        }
        JPanel headerTop = new JPanel(new BorderLayout(10, 0));
        headerTop.setOpaque(false);
        JPanel leftHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        leftHeader.setOpaque(false);
        styleButton(homeButton);
        homeButton.setFont(new Font("SansSerif", Font.BOLD, 11));
        leftHeader.add(homeButton);
        leftHeader.add(title);
        headerTop.add(leftHeader, BorderLayout.WEST);
        headerTop.add(stats, BorderLayout.EAST);
        header.add(headerTop, BorderLayout.CENTER);

        board.setBackground(PANEL);
        board.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(255, 255, 255, 24), 1),
            new EmptyBorder(14, 14, 14, 14)));
        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        center.add(board, BorderLayout.CENTER);

        JPanel footer = new JPanel();
        footer.setOpaque(false);
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        statusLabel.setForeground(Color.WHITE);
        statusLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        footer.add(statusLabel);
        footer.add(Box.createVerticalStrut(9));
        JPanel powerups = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        powerups.setOpaque(false);
        for (JButton b : new JButton[]{magnifyButton, hintButton, shieldButton, timerButton, shopButton}) {
            styleButton(b);
            powerups.add(b);
        }
        inventoryLabel.setForeground(new Color(207, 219, 244));
        inventoryLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        inventoryLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        footer.add(powerups);
        footer.add(Box.createVerticalStrut(7));
        footer.add(inventoryLabel);

        gameScreen.add(header, BorderLayout.NORTH);
        gameScreen.add(center, BorderLayout.CENTER);
        gameScreen.add(footer, BorderLayout.SOUTH);

        JPanel mainMenuScreen = createMainMenuScreen();
        JPanel levelSelectScreen = createLevelSelectScreen();
        root.add(mainMenuScreen, "main");
        root.add(levelSelectScreen, "levels");
        root.add(gameScreen, "game");
        frame.setContentPane(root);

        Toolkit.getDefaultToolkit().addAWTEventListener(event -> {
            if (event instanceof MouseEvent && ((MouseEvent) event).getID() == MouseEvent.MOUSE_PRESSED) {
                Object source = event.getSource();
                if (source instanceof JButton && !(source instanceof AnimatedCardButton)) playUiClickSound();
            }
        }, AWTEvent.MOUSE_EVENT_MASK);

        shopButton.addActionListener(e -> showShop());
        magnifyButton.addActionListener(e -> useMagnifier());
        hintButton.addActionListener(e -> useHint());
        shieldButton.addActionListener(e -> useShield());
        timerButton.addActionListener(e -> useTimerBoost());
        homeButton.addActionListener(e -> returnToLevelSelect());
        frame.setVisible(true);
    }

    private JPanel createMainMenuScreen() {
        JPanel menu = new JPanel(new BorderLayout(12, 12)) {
            @Override protected void paintComponent(Graphics graphics) {
                super.paintComponent(graphics);
                Graphics2D g = (Graphics2D) graphics.create();
                g.setPaint(new GradientPaint(0, 0, new Color(43, 35, 91),
                    getWidth(), getHeight(), BACKGROUND));
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(new Color(255, 201, 54, 22));
                for (int i = 0; i < 28; i++) {
                    int x = (i * 173 + 41) % Math.max(1, getWidth());
                    int y = (i * 97 + 29) % Math.max(1, getHeight());
                    g.fillOval(x, y, 3 + i % 4, 3 + i % 4);
                }
                g.dispose();
            }
        };
        menu.setOpaque(false);
        menu.setBorder(new EmptyBorder(22, 28, 24, 28));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel brand = new JLabel("SQUAD FLIP: WHO'S WHO?");
        brand.setForeground(GOLD);
        brand.setFont(new Font("SansSerif", Font.BOLD, 19));
        mainMenuCoinsLabel.setForeground(GOLD);
        mainMenuCoinsLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
        top.add(brand, BorderLayout.WEST);
        top.add(mainMenuCoinsLabel, BorderLayout.EAST);

        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        JLabel clouds = new JLabel("MEMORY CHALLENGE   •   50 LEVELS");
        clouds.setAlignmentX(Component.CENTER_ALIGNMENT);
        clouds.setForeground(TEAL);
        clouds.setFont(new Font("SansSerif", Font.BOLD, 14));
        JLabel title = new JLabel("SQUAD");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setForeground(GOLD);
        title.setFont(new Font("SansSerif", Font.BOLD, 52));
        JLabel flipTitle = new JLabel("FLIP");
        flipTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        flipTitle.setForeground(Color.WHITE);
        flipTitle.setFont(new Font("SansSerif", Font.BOLD, 52));
        JLabel subtitle = new JLabel("WHO'S WHO?  FLIP TO FIND OUT.");
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitle.setForeground(MUTED);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 16));

        JPanel cardPreview = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 8));
        cardPreview.setOpaque(false);
        for (String imageName : new String[]{null, "blue-face.png", "tandang-nick.jpg"}) {
            JLabel tile = new JLabel("?", SwingConstants.CENTER);
            tile.setPreferredSize(new Dimension(74, 86));
            tile.setOpaque(true);
            tile.setBackground(CARD_PURPLE);
            tile.setForeground(GOLD);
            tile.setFont(new Font("Segoe UI Emoji", Font.BOLD, 30));
            tile.setBorder(BorderFactory.createLineBorder(imageName == null ? MAGENTA : GOLD, 3));
            if (imageName != null) {
                BufferedImage image = loadCardImage(imageName);
                if (image != null) {
                    tile.setText("");
                    tile.setIcon(new ImageIcon(image.getScaledInstance(64, 72, Image.SCALE_SMOOTH)));
                }
            }
            cardPreview.add(tile);
        }

        JButton play = new JButton("▶   PLAY");
        JButton shop = new JButton("SHOP");
        JButton howTo = new JButton("HOW TO PLAY");
        JButton exit = new JButton("QUIT");
        for (JButton button : new JButton[]{play, shop, howTo, exit}) {
            styleButton(button);
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            button.setPreferredSize(new Dimension(300, 50));
            button.setMaximumSize(new Dimension(300, 50));
            button.setFont(new Font("SansSerif", Font.BOLD, 14));
        }
        play.setBackground(GOLD);
        play.setForeground(BACKGROUND);
        exit.setBackground(MAGENTA);
        play.addActionListener(event -> {
            refreshLevelSelect();
            ((CardLayout) root.getLayout()).show(root, "levels");
        });
        shop.addActionListener(event -> showShop());
        howTo.addActionListener(event -> JOptionPane.showMessageDialog(frame,
            "Choose any unlocked level from the table.\n"
            + "Flip two cards to find a matching pair. Every third wrong guess shuffles face-down cards.\n"
            + "From Level 6, Freeze Tag briefly locks a random card.\n"
            + "Clear a level for 30 coins the first time (5 coins on replay). Stars show your best rating.",
            "How to play", JOptionPane.INFORMATION_MESSAGE));
        exit.addActionListener(event -> frame.dispose());

        center.add(clouds);
        center.add(Box.createVerticalStrut(5));
        center.add(title);
        center.add(flipTitle);
        center.add(Box.createVerticalStrut(7));
        center.add(subtitle);
        center.add(Box.createVerticalStrut(16));
        center.add(cardPreview);
        center.add(Box.createVerticalStrut(14));
        for (JButton button : new JButton[]{play, shop, howTo, exit}) {
            center.add(button);
            center.add(Box.createVerticalStrut(9));
        }

        menu.add(top, BorderLayout.NORTH);
        menu.add(center, BorderLayout.CENTER);
        return menu;
    }

    private JPanel createLevelSelectScreen() {
        JPanel menu = new JPanel(new BorderLayout(16, 14)) {
            @Override protected void paintComponent(Graphics graphics) {
                super.paintComponent(graphics);
                Graphics2D g = (Graphics2D) graphics.create();
                g.setPaint(new GradientPaint(0, 0, new Color(43, 35, 91),
                    getWidth(), getHeight(), BACKGROUND));
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(new Color(255, 201, 54, 22));
                for (int i = 0; i < 22; i++) {
                    int x = (i * 173 + 41) % Math.max(1, getWidth());
                    int y = (i * 97 + 29) % Math.max(1, getHeight());
                    g.fillOval(x, y, 3 + i % 4, 3 + i % 4);
                }
                g.dispose();
            }
        };
        menu.setOpaque(false);
        menu.setBorder(new EmptyBorder(18, 24, 16, 24));

        JPanel heading = new JPanel(new BorderLayout(10, 6));
        heading.setOpaque(false);
        JPanel headingText = new JPanel();
        headingText.setOpaque(false);
        headingText.setLayout(new BoxLayout(headingText, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("SQUAD FLIP: WHO'S WHO?");
        title.setForeground(GOLD);
        title.setFont(new Font("SansSerif", Font.BOLD, 30));
        JLabel subtitle = new JLabel("SELECT A LEVEL  •  CLEARED LEVELS SHOW YOUR STARS");
        subtitle.setForeground(MUTED);
        subtitle.setFont(new Font("SansSerif", Font.BOLD, 12));
        headingText.add(title);
        headingText.add(Box.createVerticalStrut(4));
        headingText.add(subtitle);
        levelSelectCoinsLabel.setForeground(GOLD);
        levelSelectCoinsLabel.setFont(new Font("SansSerif", Font.BOLD, 17));
        heading.add(headingText, BorderLayout.WEST);
        heading.add(levelSelectCoinsLabel, BorderLayout.EAST);

        JPanel grid = new JPanel(new GridLayout(10, 5, 9, 8));
        grid.setOpaque(false);
        for (int number = 1; number <= MAX_LEVEL; number++) {
            final int selectedLevel = number;
            JButton tile = new JButton();
            styleRoundedButton(tile);
            tile.setFont(new Font("SansSerif", Font.BOLD, 13));
            tile.setFocusPainted(false);
            tile.setOpaque(true);
            tile.setBorder(new EmptyBorder(4, 4, 4, 4));
            tile.setPreferredSize(new Dimension(150, 48));
            tile.addActionListener(event -> {
                if (selectedLevel > highestUnlockedLevel) return;
                level = selectedLevel;
                gameCompleted = false;
                requestLevelStartAudio();
                ((CardLayout) root.getLayout()).show(root, "game");
                startLevel();
            });
            levelButtons[number] = tile;
            grid.add(tile);
        }

        JScrollPane scroller = new JScrollPane(grid);
        scroller.setBorder(null);
        scroller.setOpaque(false);
        scroller.getViewport().setOpaque(false);
        scroller.getVerticalScrollBar().setUnitIncrement(18);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        footer.setOpaque(false);
        JButton back = new JButton("← MAIN MENU");
        JButton shop = new JButton("🛒 POWER-UP SHOP");
        JButton howTo = new JButton("? HOW TO PLAY");
        JButton exit = new JButton("EXIT");
        for (JButton button : new JButton[]{back, shop, howTo, exit}) {
            styleButton(button);
            button.setPreferredSize(new Dimension(170, 42));
        }
        back.addActionListener(event -> ((CardLayout) root.getLayout()).show(root, "main"));
        shop.addActionListener(event -> showShop());
        howTo.addActionListener(event -> JOptionPane.showMessageDialog(frame,
            "Choose any unlocked level from the table.\n"
            + "Flip two cards to find a matching pair. Every third wrong guess shuffles face-down cards.\n"
            + "From Level 6, Freeze Tag briefly locks a random card.\n"
            + "Clear a level for 30 coins the first time (5 coins on replay). Stars show your best rating.",
            "How to play", JOptionPane.INFORMATION_MESSAGE));
        exit.addActionListener(event -> frame.dispose());
        footer.add(back);
        footer.add(shop);
        footer.add(howTo);
        footer.add(exit);

        menu.add(heading, BorderLayout.NORTH);
        menu.add(scroller, BorderLayout.CENTER);
        menu.add(footer, BorderLayout.SOUTH);
        refreshLevelSelect();
        return menu;
    }

    private void refreshLevelSelect() {
        levelSelectCoinsLabel.setText("🪙 " + coins + " COINS");
        mainMenuCoinsLabel.setText("🪙 " + coins + " COINS");
        for (int number = 1; number <= MAX_LEVEL; number++) {
            JButton tile = levelButtons[number];
            if (tile == null) continue;
            boolean unlocked = number <= highestUnlockedLevel;
            int stars = starsByLevel[number];
            String starText = "★ ".repeat(stars) + "☆ ".repeat(3 - stars);
            if (unlocked) {
                tile.setText("<html><center>LEVEL " + number + "<br><font color='#FFD76E'>"
                    + starText + "</font></center></html>");
                tile.setEnabled(true);
                tile.setForeground(Color.WHITE);
                tile.setBackground(number == level ? GOLD : new Color(43, 43, 91));
                tile.setForeground(number == level ? BACKGROUND : Color.WHITE);
                tile.setBorder(new EmptyBorder(4, 4, 4, 4));
                tile.setToolTipText("Play Level " + number + (stars > 0 ? " — best: " + stars + " stars" : ""));
            } else {
                tile.setText("<html><center>🔒<br>LEVEL " + number + "</center></html>");
                tile.setEnabled(false);
                tile.setForeground(new Color(121, 127, 157));
                tile.setBackground(new Color(27, 28, 54));
                tile.setBorder(new EmptyBorder(4, 4, 4, 4));
                tile.setToolTipText("Clear Level " + (number - 1) + " to unlock");
            }
        }
    }

    private void returnToLevelSelect() {
        if (lockCount > 0) {
            JOptionPane.showMessageDialog(frame,
                "Wait for the card animation to finish, then return to the level table.",
                "Cards are moving", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        clock.stop();
        deactivateMagnifier();
        clearFreezeTag();
        refreshLevelSelect();
        ((CardLayout) root.getLayout()).show(root, "levels");
    }

    private void styleButton(JButton b) {
        b.setForeground(Color.WHITE);
        b.setBackground(new Color(43, 43, 91));
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        styleRoundedButton(b);
    }

    private void styleRoundedButton(JButton button) {
        button.setFocusPainted(false);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setBorder(new EmptyBorder(10, 14, 15, 14));
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override public void paint(Graphics graphics, JComponent component) {
                JButton b = (JButton) component;
                Graphics2D g = (Graphics2D) graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int y = b.getModel().isPressed() ? 3 : 0;
                Color fill = b.getBackground();
                if (!b.isEnabled()) fill = new Color(49, 50, 86);
                else if (b.getModel().isPressed()) fill = fill.darker();
                g.setColor(new Color(4, 6, 22, 115));
                g.fillRoundRect(1, y + 5, b.getWidth() - 3, b.getHeight() - 8, 22, 22);
                g.setColor(fill);
                g.fillRoundRect(1, y, b.getWidth() - 3, b.getHeight() - 9, 22, 22);
                g.dispose();
                super.paint(graphics, component);
            }
        });
    }

    private void startLevel() {
        clock.stop();
        deactivateMagnifier();
        clearFreezeTag();
        secondsLeft = 300;
        wrongGuesses = 0;
        matchedPairs = 0;
        firstCard = secondCard = -1;
        lockCount = 0;
        obstaclesRemaining = level >= 6
            ? (isChallengeLevel() ? 5 + random.nextInt(3) : 3 + random.nextInt(3))
            : 0;
        cards.clear();

        int pairs = Math.min(level + 1, CARD_IMAGES.length * VARIANTS_PER_IMAGE);
        levelTimeLimit = 50 + pairs * 7;
        secondsLeft = levelTimeLimit;
        boolean challenge = isChallengeLevel();
        int theme = currentThemeIndex();
        board.setBackground(BOARD_THEMES[theme]);
        java.util.List<String> faces = new ArrayList<>();
        for (int i = 0; i < pairs; i++) {
            String imageName = CARD_IMAGES[i % CARD_IMAGES.length];
            String variant = String.valueOf((char) ('A' + i / CARD_IMAGES.length));
            String faceId = imageName + "|" + variant;
            faces.add(faceId);
            faces.add(faceId);
        }
        Collections.shuffle(faces, random);
        board.removeAll();
        boardColumns = Math.min(10, Math.max(4, (int)Math.ceil(Math.sqrt(faces.size() * 1.4))));
        boardRows = (int)Math.ceil((double)faces.size() / boardColumns);
        board.setLayout(new GridLayout(boardRows, boardColumns, 8, 8));
        for (int i = 0; i < faces.size(); i++) {
            String[] faceParts = faces.get(i).split("\\|");
            Card card = new Card(faces.get(i), faceParts[0], faceParts[1]);
            card.button.setFont(new Font("SansSerif", Font.BOLD, 42));
            card.button.setFocusPainted(false);
            card.button.setForeground(GOLD);
            card.button.setBackground(getCardBackColor());
            card.button.setContentAreaFilled(false);
            card.button.setOpaque(false);
            card.button.setRolloverEnabled(true);
            card.button.setBorder(new EmptyBorder(8, 8, 8, 8));
            card.button.setHorizontalAlignment(SwingConstants.CENTER);
            card.button.setVerticalAlignment(SwingConstants.CENTER);
            card.button.addActionListener(e -> flip(cards.indexOf(card)));
            card.button.addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent event) {
                    if (magnifierActive && !card.matched && !card.revealed) {
                        card.button.showXray(loadCardImage(card.imageName), card.imageName, card.variant);
                        statusLabel.setText("X-ray view: card " + card.variant + " revealed while you hover.");
                    }
                }

                @Override public void mouseExited(MouseEvent event) {
                    if (card.button.isXrayVisible()) {
                        card.button.showImage(null, card.variant);
                        if (magnifierActive) {
                            statusLabel.setText("X-ray active — hover a card (" + magnifierSeconds + "s left).");
                        }
                    }
                }
            });
            cards.add(card);
            board.add(card.button);
        }
        statusLabel.setText(challenge
            ? "FREEZE TAG CHALLENGE! Cards may lock briefly. " + pairs + " pairs — " + THEME_NAMES[theme] + " theme."
            : "Find " + pairs + " pairs — " + THEME_NAMES[theme] + " theme.");
        updateLabels();
        board.revalidate();
        board.repaint();
        clock.start();
    }

    private void flip(int index) {
        if (lockCount > 0 || index < 0 || index >= cards.size()) return;
        Card card = cards.get(index);
        if (card.matched || card.revealed) return;
        if (card.frozen) {
            statusLabel.setText("❄ Freeze Tag! Try another card for a moment.");
            return;
        }
        playSound("flip");
        reveal(index);
        if (firstCard < 0) {
            firstCard = index;
            return;
        }
        secondCard = index;
        Card first = cards.get(firstCard);
        if (first.face.equals(card.face)) {
            playSound("match");
            first.matched = card.matched = true;
            first.button.setBackground(new Color(52, 126, 104));
            card.button.setBackground(new Color(52, 126, 104));
            matchedPairs++;
            firstCard = secondCard = -1;
            lockCount++;
            statusLabel.setText("Match! Nice one!");
            final int[] completedAnimations = {0};
            Runnable finishOne = () -> {
                completedAnimations[0]++;
                if (completedAnimations[0] == 2) {
                    first.button.setVisible(false);
                    card.button.setVisible(false);
                    lockCount--;
                    if (matchedPairs == cards.size() / 2) levelWon();
                    else maybeTriggerObstacle();
                }
            };
            first.button.playMatch(finishOne);
            card.button.playMatch(finishOne);
        } else {
            playSound("wrong");
            final boolean shielded = shieldArmed;
            if (shielded) {
                shieldArmed = false;
                saveProgress();
                updateLabels();
            } else {
                wrongGuesses++;
            }
            int a = firstCard, b = secondCard;
            lockCount++;
            statusLabel.setText(shielded
                ? "🛡 Shield absorbed the mistake — no shuffle!"
                : wrongGuesses % 3 == 0
                ? "⚠ Three wrong guesses! Unflipped cards are being shuffled!"
                : "Not a match — try again.");
            javax.swing.Timer pause = new javax.swing.Timer(850, e -> {
                hide(a);
                hide(b);
                firstCard = secondCard = -1;
                lockCount--;
                if (shielded) maybeTriggerObstacle();
                else if (wrongGuesses % 3 == 0) shuffleUnflippedCards();
                else maybeTriggerObstacle();
                if (statusLabel.getText().startsWith("Not a match")) statusLabel.setText("Keep going!");
            });
            pause.setRepeats(false);
            pause.start();
        }
    }

    private void reveal(int index) {
        Card c = cards.get(index);
        c.revealed = true;
        c.button.showImage(loadCardImage(c.imageName), c.imageName, c.variant);
        c.button.setBackground(new Color(100, 126, 180));
        c.button.playFlip();
    }

    private void hide(int index) {
        Card c = cards.get(index);
        if (!c.matched) {
            c.revealed = false;
            c.button.showImage(null, c.variant);
            c.button.setBackground(getCardBackColor());
            c.button.playFlip();
        }
    }

    private void shuffleUnflippedCards() {
        java.util.List<Integer> positions = new ArrayList<>();
        for (int i = 0; i < cards.size(); i++) {
            Card card = cards.get(i);
            if (!card.matched && !card.revealed) positions.add(i);
        }

        if (positions.size() < 2) return;
        playSound("shuffle");
        statusLabel.setText("⚠ Cards are sliding to new spots!");
        lockCount++;

        java.util.List<Card> shuffledOrder = new ArrayList<>(cards);
        java.util.List<Card> movingCards = new ArrayList<>();
        for (int position : positions) movingCards.add(shuffledOrder.get(position));
        java.util.List<Card> originalMovingOrder = new ArrayList<>(movingCards);
        Collections.shuffle(movingCards, random);
        if (movingCards.equals(originalMovingOrder)) {
            Collections.rotate(movingCards, 1);
        }
        for (int i = 0; i < positions.size(); i++) {
            shuffledOrder.set(positions.get(i), movingCards.get(i));
        }

        java.util.List<Rectangle> destinations = new ArrayList<>();
        java.util.List<Rectangle> starts = new ArrayList<>();
        for (int position : positions) {
            destinations.add(cards.get(position).button.getBounds());
            starts.add(shuffledOrder.get(position).button.getBounds());
        }

        GridLayout originalLayout = board.getLayout() instanceof GridLayout
            ? (GridLayout) board.getLayout() : new GridLayout(boardRows, boardColumns, 8, 8);
        board.setLayout(null);
        long started = System.nanoTime();
        int durationMs = 620;
        javax.swing.Timer animation = new javax.swing.Timer(16, null);
        animation.addActionListener(event -> {
            double progress = Math.min(1.0,
                (System.nanoTime() - started) / (durationMs * 1_000_000.0));
            double eased = progress * progress * (3.0 - 2.0 * progress);
            for (int i = 0; i < positions.size(); i++) {
                Rectangle from = starts.get(i);
                Rectangle to = destinations.get(i);
                int x = (int) (from.x + (to.x - from.x) * eased);
                int y = (int) (from.y + (to.y - from.y) * eased
                    - Math.sin(progress * Math.PI) * 12);
                int width = (int) (from.width + (to.width - from.width) * eased);
                int height = (int) (from.height + (to.height - from.height) * eased);
                shuffledOrder.get(positions.get(i)).button.setBounds(x, y, width, height);
            }
            board.repaint();
            if (progress >= 1.0) {
                animation.stop();
                cards.clear();
                cards.addAll(shuffledOrder);
                board.removeAll();
                board.setLayout(originalLayout);
                for (Card card : cards) board.add(card.button);
                board.revalidate();
                board.repaint();
                lockCount--;
                statusLabel.setText("⚠ Cards shuffled! Find their new positions.");
                maybeTriggerObstacle();
            }
        });
        animation.start();
    }

    private void maybeTriggerObstacle() {
        if (level < 6 || obstaclesRemaining <= 0 || obstacleActive) return;
        int chance = isChallengeLevel() ? 45 : 28;
        if (random.nextInt(100) < chance) triggerFreezeTag();
    }

    private boolean isChallengeLevel() {
        return level % 10 == 0;
    }

    private int currentThemeIndex() {
        return Math.max(0, ((level - 1) / 5) % THEME_NAMES.length);
    }

    private Color getCardBackColor() {
        return selectedCardBack == 0 ? THEME_CARD_BACKS[currentThemeIndex()] : CARD_BACK_SKINS[selectedCardBack];
    }

    private void triggerFreezeTag() {
        java.util.List<Card> hidden = new ArrayList<>();
        for (Card card : cards) {
            if (!card.matched && !card.revealed && !card.frozen && !card.button.isXrayVisible()) hidden.add(card);
        }
        if (hidden.isEmpty()) return;
        Card frozen = hidden.get(random.nextInt(hidden.size()));
        obstaclesRemaining--;
        obstacleActive = true;
        frozenObstacleCard = frozen;
        frozen.frozen = true;
        frozen.button.setFrozenVisible(true);
        playSound("freeze");
        statusLabel.setText("❄ FREEZE TAG! One card is locked for 3 seconds—try another.");

        if (obstacleTimer != null) obstacleTimer.stop();
        obstacleTimer = new javax.swing.Timer(3000, event -> clearFreezeTag());
        obstacleTimer.setRepeats(false);
        obstacleTimer.start();
    }

    private void clearFreezeTag() {
        if (obstacleTimer != null) obstacleTimer.stop();
        obstacleTimer = null;
        obstacleActive = false;
        if (frozenObstacleCard != null) {
            frozenObstacleCard.frozen = false;
            frozenObstacleCard.button.setFrozenVisible(false);
            frozenObstacleCard = null;
        }
    }

    private void levelWon() {
        clock.stop();
        clearFreezeTag();
        lastLevelReward = starsByLevel[level] == 0 ? 30 : 5;
        coins += lastLevelReward;
        int earnedStars = calculateStarRating();
        starsByLevel[level] = Math.max(starsByLevel[level], earnedStars);
        updateLabels();
        boolean finalLevel = level >= MAX_LEVEL;
        if (finalLevel) {
            gameCompleted = true;
        } else {
            highestUnlockedLevel = Math.max(highestUnlockedLevel, level + 1);
        }
        refreshLevelSelect();
        saveProgress();
        if (showLevelCompleteDialog(finalLevel, earnedStars)) {
            if (finalLevel) {
                refreshLevelSelect();
                ((CardLayout) root.getLayout()).show(root, "levels");
            } else {
                level++;
                saveProgress();
                ((CardLayout) root.getLayout()).show(root, "game");
                startLevel();
            }
        } else {
            statusLabel.setText(finalLevel
                ? "All 50 levels cleared! Return to the menu to start again."
                : "Level cleared! Visit the shop when you are ready for the next level.");
        }
    }

    private int calculateStarRating() {
        int pairs = cards.size() / 2;
        double timeLeftRatio = (double) secondsLeft / Math.max(1, levelTimeLimit);
        if (wrongGuesses <= Math.max(1, pairs / 3) && timeLeftRatio >= 0.35) return 3;
        if (wrongGuesses <= pairs && secondsLeft > 0) return 2;
        return 1;
    }

    private boolean showLevelCompleteDialog(boolean finalLevel, int earnedStars) {
        final boolean[] continueGame = {false};
        JDialog dialog = new JDialog(frame, finalLevel ? "GAME COMPLETE" : "LEVEL CLEARED", true);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setSize(520, 430);
        dialog.setResizable(false);

        JPanel panel = new JPanel(new BorderLayout(14, 14));
        panel.setBackground(new Color(20, 29, 51));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(109, 157, 204), 2),
            new EmptyBorder(22, 26, 22, 26)));

        JPanel headline = new JPanel();
        headline.setOpaque(false);
        headline.setLayout(new BoxLayout(headline, BoxLayout.Y_AXIS));
        JLabel badge = new JLabel(finalLevel ? "✦  GAME COMPLETE  ✦" : "✦  LEVEL CLEARED  ✦");
        badge.setAlignmentX(Component.CENTER_ALIGNMENT);
        badge.setForeground(new Color(136, 235, 196));
        badge.setFont(new Font("SansSerif", Font.BOLD, 15));
        JLabel title = new JLabel(finalLevel ? "You did it!" : "Great memory!");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 32));
        JLabel subtitle = new JLabel(finalLevel
            ? "You finished all 50 levels!" : "You found every matching card.");
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitle.setForeground(new Color(196, 210, 238));
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 15));
        headline.add(badge);
        headline.add(Box.createVerticalStrut(8));
        headline.add(title);
        headline.add(Box.createVerticalStrut(5));
        JLabel starDisplay = new JLabel("★ ".repeat(earnedStars) + "☆ ".repeat(3 - earnedStars));
        starDisplay.setAlignmentX(Component.CENTER_ALIGNMENT);
        starDisplay.setForeground(new Color(255, 213, 103));
        starDisplay.setFont(new Font("SansSerif", Font.BOLD, 25));
        headline.add(starDisplay);
        headline.add(Box.createVerticalStrut(3));
        headline.add(subtitle);

        JPanel stats = new JPanel(new GridLayout(1, 2, 12, 0));
        stats.setOpaque(false);
        stats.add(makeLevelStat("REWARD", "+" + lastLevelReward, "COINS", new Color(255, 216, 118)));
        stats.add(finalLevel
            ? makeLevelStat("CAMPAIGN", "50", "LEVELS DONE", new Color(142, 199, 255))
            : makeLevelStat("UP NEXT", "LEVEL " + (level + 1), "READY", new Color(142, 199, 255)));

        JButton stay = new JButton("STAY HERE");
        JButton next = new JButton(finalLevel ? "RETURN TO MENU" : "CONTINUE  →");
        styleButton(stay);
        styleButton(next);
        stay.setPreferredSize(new Dimension(150, 44));
        next.setPreferredSize(new Dimension(180, 44));
        next.setBackground(new Color(50, 143, 119));
        next.setBorder(BorderFactory.createLineBorder(new Color(112, 218, 181), 2));
        stay.addActionListener(event -> dialog.dispose());
        next.addActionListener(event -> {
            continueGame[0] = true;
            dialog.dispose();
        });

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        actions.setOpaque(false);
        actions.add(stay);
        actions.add(next);

        JPanel center = new JPanel(new BorderLayout(0, 16));
        center.setOpaque(false);
        JLabel balance = new JLabel("Your coin balance: " + coins, SwingConstants.CENTER);
        balance.setForeground(new Color(205, 218, 241));
        center.add(stats, BorderLayout.CENTER);
        center.add(balance, BorderLayout.SOUTH);

        panel.add(headline, BorderLayout.NORTH);
        panel.add(center, BorderLayout.CENTER);
        panel.add(actions, BorderLayout.SOUTH);
        dialog.setContentPane(panel);
        dialog.getRootPane().setDefaultButton(next);
        dialog.setLocationRelativeTo(frame);
        requestBonusAudio();
        dialog.setVisible(true);
        return continueGame[0];
    }

    private JPanel makeLevelStat(String heading, String value, String footnote, Color accent) {
        JPanel card = new JPanel();
        card.setBackground(new Color(36, 49, 77));
        card.setBorder(BorderFactory.createLineBorder(new Color(75, 99, 139), 1));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel top = new JLabel(heading);
        JLabel amount = new JLabel(value);
        JLabel bottom = new JLabel(footnote);
        for (JLabel label : new JLabel[]{top, amount, bottom}) {
            label.setAlignmentX(Component.CENTER_ALIGNMENT);
        }
        top.setForeground(new Color(182, 197, 224));
        top.setFont(new Font("SansSerif", Font.BOLD, 12));
        amount.setForeground(accent);
        amount.setFont(new Font("SansSerif", Font.BOLD, 25));
        bottom.setForeground(new Color(182, 197, 224));
        bottom.setFont(new Font("SansSerif", Font.BOLD, 11));
        card.add(Box.createVerticalGlue());
        card.add(top);
        card.add(Box.createVerticalStrut(7));
        card.add(amount);
        card.add(Box.createVerticalStrut(4));
        card.add(bottom);
        card.add(Box.createVerticalGlue());
        return card;
    }

    private void tick() {
        secondsLeft--;
        updateLabels();
        if (secondsLeft <= 0) {
            clock.stop();
            clearFreezeTag();
            int choice = JOptionPane.showConfirmDialog(frame,
                "Time is up! The level will restart. Your coins and power-ups are safe.",
                "Time up", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
            startLevel();
        }
    }

    private void showShop() {
        JDialog dialog = new JDialog(frame, "POWER-UP SHOP", true);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setSize(850, 570);
        dialog.setResizable(false);

        JPanel content = new JPanel(new BorderLayout(16, 16));
        content.setBackground(BACKGROUND);
        content.setBorder(new EmptyBorder(22, 24, 20, 24));

        JPanel heading = new JPanel(new BorderLayout());
        heading.setOpaque(false);
        JLabel title = new JLabel("POWER-UP SHOP");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 26));
        JLabel balance = new JLabel("🪙 " + coins + " COINS");
        balance.setForeground(GOLD);
        balance.setFont(new Font("SansSerif", Font.BOLD, 16));
        heading.add(title, BorderLayout.WEST);
        heading.add(balance, BorderLayout.EAST);

        JPanel tiles = new JPanel(new GridLayout(0, 3, 13, 13));
        tiles.setOpaque(false);
        String[] names = {"MAGNIFIER", "PAIR HINT", "MISTAKE SHIELD", "EXTRA TIME"};
        String[] icons = {"🔍", "💡", "🛡", "⏱"};
        String[] details = {
            "Hover over cards to X-ray them for 3 seconds.",
            "Briefly reveal one matching pair.",
            "Cancel the next wrong guess and avoid its shuffle.",
            "Add 60 seconds to the level timer."
        };
        int[] costs = {50, 80, 60, 40};
        for (int i = 0; i < names.length; i++) {
            final int item = i;
            JButton tile = new JButton("<html><div style='text-align:center;width:190px'>"
                + "<font size='+4'>" + icons[i] + "</font><br><br>"
                + "<b><font size='+1'>" + names[i] + "</font></b><br><br>"
                + "<font color='#D4DEF2'>" + details[i] + "</font><br><br>"
                + "<font color='#FFDA76'><b>" + costs[i] + " COINS</b></font></div></html>");
            tile.setFont(new Font("SansSerif", Font.PLAIN, 13));
            tile.setForeground(Color.WHITE);
            tile.setBackground(new Color(43, 43, 91));
            tile.setOpaque(true);
            tile.setFocusPainted(false);
            tile.setContentAreaFilled(true);
            tile.setBorder(BorderFactory.createLineBorder(new Color(219, 31, 112), 2));
            tile.setPreferredSize(new Dimension(300, 185));
            tile.addActionListener(event -> {
                if (coins < costs[item]) {
                    statusLabel.setText("You need " + costs[item] + " coins for " + names[item] + ".");
                    return;
                }
                coins -= costs[item];
                switch (item) {
                    case 0: magnifiers++; break;
                    case 1: hints++; break;
                    case 2: shields++; break;
                    case 3: timerBoosts++; break;
                    default: break;
                }
                updateLabels();
                saveProgress();
                refreshLevelSelect();
                balance.setText("🪙 " + coins + " COINS");
                statusLabel.setText(names[item] + " purchased!");
            });
            tiles.add(tile);
        }

        JButton backsTile = new JButton("<html><div style='text-align:center;width:190px'>"
            + "<font size='+4'>🎨</font><br><br><b><font size='+1'>CARD BACKS</font></b><br><br>"
            + "Unlock new designs and equip your favorite card style.<br><br>OPEN DESIGNS →</div></html>");
        backsTile.setFont(new Font("SansSerif", Font.PLAIN, 13));
        backsTile.setForeground(Color.WHITE);
        backsTile.setBackground(new Color(54, 67, 96));
        backsTile.setOpaque(true);
        backsTile.setFocusPainted(false);
        backsTile.setBorder(BorderFactory.createLineBorder(new Color(205, 175, 255), 2));
        backsTile.setPreferredSize(new Dimension(260, 185));
        backsTile.addActionListener(event -> {
            dialog.dispose();
            showCardBackShop();
        });
        tiles.add(backsTile);

        JLabel caption = new JLabel("Choose a square to buy a power-up", SwingConstants.CENTER);
        caption.setForeground(new Color(191, 205, 232));
        JButton close = new JButton("CLOSE");
        styleButton(close);
        close.addActionListener(event -> dialog.dispose());

        content.add(heading, BorderLayout.NORTH);
        content.add(tiles, BorderLayout.CENTER);
        JPanel footer = new JPanel(new BorderLayout(8, 4));
        footer.setOpaque(false);
        footer.add(caption, BorderLayout.CENTER);
        footer.add(close, BorderLayout.EAST);
        content.add(footer, BorderLayout.SOUTH);
        dialog.setContentPane(content);
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }

    private void showCardBackShop() {
        JDialog dialog = new JDialog(frame, "CARD BACK DESIGNS", true);
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.setSize(620, 500);
        dialog.setResizable(false);

        JPanel content = new JPanel(new BorderLayout(14, 14));
        content.setBackground(new Color(21, 29, 51));
        content.setBorder(new EmptyBorder(20, 22, 18, 22));
        JLabel title = new JLabel("CARD BACK DESIGNS");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        JLabel balance = new JLabel("🪙 " + coins + " COINS");
        balance.setForeground(new Color(255, 218, 118));
        balance.setFont(new Font("SansSerif", Font.BOLD, 15));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(title, BorderLayout.WEST);
        header.add(balance, BorderLayout.EAST);

        JPanel tiles = new JPanel(new GridLayout(2, 2, 12, 12));
        tiles.setOpaque(false);
        String[] colorCodes = {"#D4DEF2", "#F1D7FF", "#C8F4F5", "#FFE0E6"};
        for (int i = 0; i < CARD_BACK_NAMES.length; i++) {
            final int skin = i;
            String state = !unlockedCardBacks[i]
                ? CARD_BACK_PRICES[i] + " COINS"
                : (selectedCardBack == i ? "EQUIPPED" : "OWNED · CLICK TO EQUIP");
            JButton tile = new JButton("<html><div style='text-align:center;width:190px'>"
                + "<font size='+4'>✦</font><br><br><b>" + CARD_BACK_NAMES[i]
                + "</b><br><br><font color='" + colorCodes[i] + "'>" + state + "</font></div></html>");
            tile.setFont(new Font("SansSerif", Font.BOLD, 14));
            tile.setForeground(Color.WHITE);
            tile.setBackground(i == 0 ? getCardBackColor() : CARD_BACK_SKINS[i]);
            tile.setOpaque(true);
            tile.setFocusPainted(false);
            tile.setBorder(BorderFactory.createLineBorder(new Color(210, 221, 243), 2));
            tile.addActionListener(event -> {
                if (!unlockedCardBacks[skin]) {
                    if (coins < CARD_BACK_PRICES[skin]) {
                        JOptionPane.showMessageDialog(dialog,
                            "You need " + CARD_BACK_PRICES[skin] + " coins to unlock this design.",
                            "Not enough coins", JOptionPane.INFORMATION_MESSAGE);
                        return;
                    }
                    coins -= CARD_BACK_PRICES[skin];
                    unlockedCardBacks[skin] = true;
                }
                selectedCardBack = skin;
                applyCardBack();
                updateLabels();
                saveProgress();
                refreshLevelSelect();
                balance.setText("🪙 " + coins + " COINS");
                tile.setText("<html><div style='text-align:center;width:190px'>"
                    + "<font size='+4'>✦</font><br><br><b>" + CARD_BACK_NAMES[skin]
                    + "</b><br><br><font color='" + colorCodes[skin] + "'>EQUIPPED</font></div></html>");
            });
            tiles.add(tile);
        }

        JButton close = new JButton("DONE");
        styleButton(close);
        close.addActionListener(event -> dialog.dispose());
        content.add(header, BorderLayout.NORTH);
        content.add(tiles, BorderLayout.CENTER);
        content.add(close, BorderLayout.SOUTH);
        dialog.setContentPane(content);
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }

    private void applyCardBack() {
        for (Card card : cards) {
            if (!card.matched && !card.revealed) card.button.setBackground(getCardBackColor());
        }
        board.repaint();
    }

    private void useMagnifier() {
        if (magnifierActive) {
            statusLabel.setText("Magnifier is already active — hover over a card!");
            return;
        }
        if (magnifiers <= 0) { noPowerUp("Magnifying glasses"); return; }
        magnifiers--;
        magnifierActive = true;
        magnifierSeconds = 3;
        statusLabel.setText("🔍 X-ray active — hover over a card to inspect it (3 seconds).");
        pulsePowerButton(magnifyButton);
        saveProgress();
        magnifierTimer = new javax.swing.Timer(1000, e -> {
            magnifierSeconds--;
            if (magnifierSeconds <= 0) {
                deactivateMagnifier();
                statusLabel.setText("Magnifier expired. Buy another in the shop.");
            } else {
                updateLabels();
            }
        });
        magnifierTimer.start();
        updateLabels();
    }

    private void deactivateMagnifier() {
        if (magnifierTimer != null) {
            magnifierTimer.stop();
            magnifierTimer = null;
        }
        magnifierActive = false;
        magnifierSeconds = 0;
        for (Card card : cards) {
            if (card.button.isXrayVisible()) card.button.showImage(null, card.variant);
        }
        updateLabels();
    }

    private void pulsePowerButton(JButton button) {
        Color normal = button.getBackground();
        Color glow = new Color(91, 190, 210);
        final int[] ticks = {0};
        javax.swing.Timer pulse = new javax.swing.Timer(90, null);
        pulse.addActionListener(e -> {
            button.setBackground(ticks[0]++ % 2 == 0 ? glow : normal);
            if (ticks[0] >= 8) {
                pulse.stop();
                button.setBackground(normal);
            }
        });
        pulse.start();
    }

    private void useHint() {
        if (hints <= 0) { noPowerUp("Hints"); return; }
        Map<String, java.util.List<Integer>> found = new HashMap<>();
        for (int i = 0; i < cards.size(); i++) {
            Card c = cards.get(i);
            if (!c.matched && !c.revealed) found.computeIfAbsent(c.face, k -> new ArrayList<>()).add(i);
        }
        java.util.List<Integer> pair = null;
        for (java.util.List<Integer> indexes : found.values()) if (indexes.size() >= 2) { pair = indexes; break; }
        if (pair == null) return;
        hints--;
        saveProgress();
        int a = pair.get(0), b = pair.get(1);
        for (int i : new int[]{a, b}) {
            Card card = cards.get(i);
            card.button.showImage(loadCardImage(card.imageName), card.imageName, card.variant);
            card.button.setHintVisible(true);
            cards.get(i).button.setBackground(new Color(191, 153, 67));
        }
        statusLabel.setText("Hint: these two cards match!");
        javax.swing.Timer t = new javax.swing.Timer(1500, e -> {
            for (int i : new int[]{a, b}) if (!cards.get(i).matched && !cards.get(i).revealed) {
                cards.get(i).button.setHintVisible(false);
                cards.get(i).button.showImage(null, cards.get(i).variant);
                cards.get(i).button.setBackground(getCardBackColor());
            }
        });
        t.setRepeats(false); t.start();
        updateLabels();
    }

    private void useShield() {
        if (shieldArmed) {
            statusLabel.setText("Shield is armed for your next wrong guess.");
            return;
        }
        if (shields <= 0) { noPowerUp("Mistake shields"); return; }
        shields--;
        shieldArmed = true;
        saveProgress();
        pulsePowerButton(shieldButton);
        statusLabel.setText("🛡 Shield armed — it will block your next wrong guess.");
        updateLabels();
    }

    private void useTimerBoost() {
        if (timerBoosts <= 0) { noPowerUp("Extra-time boosts"); return; }
        timerBoosts--;
        saveProgress();
        secondsLeft += 60;
        statusLabel.setText("60 seconds added!");
        updateLabels();
    }

    private void noPowerUp(String name) {
        statusLabel.setText("No " + name + " left. Buy more in the shop.");
    }

    private static BufferedImage loadCardImage(String imageName) {
        if (IMAGE_CACHE.containsKey(imageName)) return IMAGE_CACHE.get(imageName);
        File file = findAssetFile(imageName);
        if (file != null) {
            try {
                BufferedImage image = ImageIO.read(file);
                if (image != null) {
                    IMAGE_CACHE.put(imageName, image);
                    return image;
                }
            } catch (Exception ex) {
                System.err.println("Could not load card image " + file + ": " + ex.getMessage());
            }
        }
        System.err.println("Card image not found: " + imageName + " (keep the assets folder beside MemoryFogGame.java)");
        return null;
    }

    private static File findAssetFile(String assetName) {
        java.util.List<File> locations = new ArrayList<>();
        File working = new File(System.getProperty("user.dir"));
        locations.add(new File(working, "assets/" + assetName));
        locations.add(new File(working, "outputs/assets/" + assetName));
        try {
            File classes = new File(MemoryFogGame.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI());
            if (classes.isFile()) classes = classes.getParentFile();
            locations.add(new File(classes, "assets/" + assetName));
            locations.add(new File(classes, "outputs/assets/" + assetName));
            File parent = classes.getParentFile();
            if (parent != null) {
                locations.add(new File(parent, "assets/" + assetName));
                locations.add(new File(parent, "outputs/assets/" + assetName));
            }
        } catch (Exception ignored) {
            // The working-directory locations still work if class metadata is unavailable.
        }
        for (File file : locations) if (file.isFile()) return file;
        return null;
    }

    private void flashBoard(Color color) {
        Color original = board.getBackground();
        board.setBackground(color);
        javax.swing.Timer t = new javax.swing.Timer(350, e -> board.setBackground(original));
        t.setRepeats(false); t.start();
    }

    private void preloadUiClickAudio() {
        uiClickAudio = new AudioClip("universfield-bubble-pop-05-323639.mp3");
    }

    private void playUiClickSound() {
        if (uiClickAudio == null || !uiClickAudio.play()) playSound("click");
    }

    /** Preloads one MP3 in a hidden player and reuses it for each button press. */
    private static class AudioClip {
        private Process process;
        private File requestFile;
        private int requestId;

        AudioClip(String assetName) {
            File audio = findAssetFile(assetName);
            if (audio == null || !System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("windows")) return;
            try {
                requestFile = File.createTempFile("squad-flip-ui-audio-", ".txt");
                requestFile.deleteOnExit();
                java.nio.file.Files.write(requestFile.toPath(), "0".getBytes(java.nio.charset.StandardCharsets.UTF_8));
                String uri = audio.toURI().toString().replace("'", "''");
                String requestPath = requestFile.getAbsolutePath().replace("'", "''");
                String parentPid = Long.toString(ProcessHandle.current().pid());
                String script = "$ErrorActionPreference='SilentlyContinue'; Add-Type -AssemblyName PresentationCore,WindowsBase; "
                    + "$script:ready=$false; $script:pending=$false; $script:last='0'; $script:parent=" + parentPid + "; "
                    + "$player=New-Object System.Windows.Media.MediaPlayer; $player.Volume=1.0; "
                    + "$player.add_MediaOpened({$script:ready=$true;if($script:pending){$player.Position=[TimeSpan]::Zero;$player.Play();$script:pending=$false}}); "
                    + "$player.add_MediaFailed({$script:ready=$false}); $player.Open([Uri]::new('" + uri + "')); "
                    + "$frame=New-Object System.Windows.Threading.DispatcherFrame; $timer=New-Object System.Windows.Threading.DispatcherTimer; "
                    + "$timer.Interval=[TimeSpan]::FromMilliseconds(20); $timer.add_Tick({ "
                    + "try{$v=[IO.File]::ReadAllText('" + requestPath + "').Trim();if($v -ne $script:last){$script:last=$v;$script:pending=$true;if($script:ready){$player.Stop();$player.Position=[TimeSpan]::Zero;$player.Play();$script:pending=$false}}}catch{}; "
                    + "try{[void][Diagnostics.Process]::GetProcessById($script:parent)}catch{$frame.Continue=$false;$timer.Stop()} }); "
                    + "$timer.Start();[System.Windows.Threading.Dispatcher]::PushFrame($frame);$player.Close()";
                process = new ProcessBuilder("powershell.exe", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-Command", script)
                    .redirectOutput(ProcessBuilder.Redirect.DISCARD)
                    .redirectError(ProcessBuilder.Redirect.DISCARD)
                    .start();
            } catch (Exception ignored) { process = null; }
        }

        boolean play() {
            if (process == null || !process.isAlive() || requestFile == null) return false;
            try {
                String request = Integer.toString(++requestId);
                java.nio.file.Files.write(requestFile.toPath(), request.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                return true;
            } catch (Exception ignored) { return false; }
        }
    }

    /** Loads the bundled MP3 once during startup so level selection has no player startup delay. */
    private void preloadLevelStartAudio() {
        File audio = findAssetFile("game-start.mp3");
        if (audio == null || !System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("windows")) return;
        try {
            levelAudioRequestFile = File.createTempFile("squad-flip-audio-", ".txt");
            levelAudioRequestFile.deleteOnExit();
            java.nio.file.Files.write(levelAudioRequestFile.toPath(), "0".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            String uri = audio.toURI().toString().replace("'", "''");
            String requestPath = levelAudioRequestFile.getAbsolutePath().replace("'", "''");
            String parentPid = Long.toString(ProcessHandle.current().pid());
            String script = "$ErrorActionPreference='SilentlyContinue'; Add-Type -AssemblyName PresentationCore,WindowsBase; "
                + "$script:ready=$false; $script:pending=$false; $script:last='0'; $script:parent=" + parentPid + "; "
                + "$player=New-Object System.Windows.Media.MediaPlayer; $player.Volume=1.0; "
                + "$player.add_MediaOpened({$script:ready=$true;if($script:pending){$player.Position=[TimeSpan]::Zero;$player.Play();$script:pending=$false}}); "
                + "$player.add_MediaFailed({$script:ready=$false}); $player.Open([Uri]::new('" + uri + "')); "
                + "$frame=New-Object System.Windows.Threading.DispatcherFrame; $timer=New-Object System.Windows.Threading.DispatcherTimer; "
                + "$timer.Interval=[TimeSpan]::FromMilliseconds(25); $timer.add_Tick({ "
                + "try{$v=[IO.File]::ReadAllText('" + requestPath + "').Trim();if($v -ne $script:last){$script:last=$v;$script:pending=$true;if($script:ready){$player.Stop();$player.Position=[TimeSpan]::Zero;$player.Play();$script:pending=$false}}}catch{}; "
                + "try{[void][Diagnostics.Process]::GetProcessById($script:parent)}catch{$frame.Continue=$false;$timer.Stop()} }); "
                + "$timer.Start();[System.Windows.Threading.Dispatcher]::PushFrame($frame);$player.Close()";
            levelAudioProcess = new ProcessBuilder("powershell.exe", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-Command", script)
                .redirectOutput(ProcessBuilder.Redirect.DISCARD)
                .redirectError(ProcessBuilder.Redirect.DISCARD)
                .start();
        } catch (Exception ignored) {
            levelAudioProcess = null;
        }
    }

    /** Requests playback from the preloaded media player as soon as a level is selected. */
    private void requestLevelStartAudio() {
        if (levelAudioProcess == null || !levelAudioProcess.isAlive() || levelAudioRequestFile == null) {
            playSound("start");
            return;
        }
        try {
            String request = Integer.toString(++levelAudioRequestId);
            java.nio.file.Files.write(levelAudioRequestFile.toPath(), request.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        } catch (Exception ignored) { playSound("start"); }
    }

    /** Preloads the level-clear fanfare so it can play as soon as the win panel appears. */
    private void preloadBonusAudio() {
        File audio = findAssetFile("game-bonus.mp3");
        if (audio == null || !System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("windows")) return;
        try {
            bonusAudioRequestFile = File.createTempFile("squad-flip-bonus-", ".txt");
            bonusAudioRequestFile.deleteOnExit();
            java.nio.file.Files.write(bonusAudioRequestFile.toPath(), "0".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            String uri = audio.toURI().toString().replace("'", "''");
            String requestPath = bonusAudioRequestFile.getAbsolutePath().replace("'", "''");
            String parentPid = Long.toString(ProcessHandle.current().pid());
            String script = "$ErrorActionPreference='SilentlyContinue'; Add-Type -AssemblyName PresentationCore,WindowsBase; "
                + "$script:ready=$false; $script:pending=$false; $script:last='0'; $script:parent=" + parentPid + "; "
                + "$player=New-Object System.Windows.Media.MediaPlayer; $player.Volume=1.0; "
                + "$player.add_MediaOpened({$script:ready=$true;if($script:pending){$player.Position=[TimeSpan]::Zero;$player.Play();$script:pending=$false}}); "
                + "$player.add_MediaFailed({$script:ready=$false}); $player.Open([Uri]::new('" + uri + "')); "
                + "$frame=New-Object System.Windows.Threading.DispatcherFrame; $timer=New-Object System.Windows.Threading.DispatcherTimer; "
                + "$timer.Interval=[TimeSpan]::FromMilliseconds(25); $timer.add_Tick({ "
                + "try{$v=[IO.File]::ReadAllText('" + requestPath + "').Trim();if($v -ne $script:last){$script:last=$v;$script:pending=$true;if($script:ready){$player.Stop();$player.Position=[TimeSpan]::Zero;$player.Play();$script:pending=$false}}}catch{}; "
                + "try{[void][Diagnostics.Process]::GetProcessById($script:parent)}catch{$frame.Continue=$false;$timer.Stop()} }); "
                + "$timer.Start();[System.Windows.Threading.Dispatcher]::PushFrame($frame);$player.Close()";
            bonusAudioProcess = new ProcessBuilder("powershell.exe", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-Command", script)
                .redirectOutput(ProcessBuilder.Redirect.DISCARD)
                .redirectError(ProcessBuilder.Redirect.DISCARD)
                .start();
        } catch (Exception ignored) {
            bonusAudioProcess = null;
        }
    }

    private void requestBonusAudio() {
        if (bonusAudioProcess == null || !bonusAudioProcess.isAlive() || bonusAudioRequestFile == null) {
            playSound("win");
            return;
        }
        try {
            String request = Integer.toString(++bonusAudioRequestId);
            java.nio.file.Files.write(bonusAudioRequestFile.toPath(), request.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        } catch (Exception ignored) { playSound("win"); }
    }

    /** Generates short, distinct sound cues with Java's built-in audio support. */
    private void playSound(String kind) {
        Thread soundThread = new Thread(() -> {
            final float sampleRate = 22050f;
            AudioFormat format = new AudioFormat(sampleRate, 16, 1, true, false);
            double[][] notes;
            switch (kind) {
                case "wrong": notes = new double[][]{{290, 100}, {205, 155}}; break;
                case "match": notes = new double[][]{{523, 85}, {659, 85}, {784, 170}}; break;
                case "shuffle": notes = new double[][]{{260, 60}, {360, 65}, {480, 75}, {330, 95}}; break;
                case "freeze": notes = new double[][]{{880, 65}, {660, 90}, {440, 140}}; break;
                case "start": notes = new double[][]{{523, 90}, {659, 90}, {784, 160}}; break;
                case "win": notes = new double[][]{{523, 80}, {659, 80}, {784, 90}, {1047, 240}}; break;
                case "click": notes = new double[][]{{880, 45}, {1175, 55}}; break;
                default: notes = new double[][]{{740, 55}}; break;
            }

            try (SourceDataLine line = AudioSystem.getSourceDataLine(format)) {
                line.open(format);
                line.start();
                for (double[] note : notes) {
                    double frequency = note[0];
                    int frames = (int) (sampleRate * note[1] / 1000.0);
                    byte[] pcm = new byte[frames * 2];
                    for (int i = 0; i < frames; i++) {
                        double progress = (double) i / frames;
                        double envelope = Math.min(1.0, Math.min(progress * 14.0, (1.0 - progress) * 9.0));
                        double sample = Math.sin(2.0 * Math.PI * frequency * i / sampleRate)
                            * envelope * 0.22;
                        short value = (short) (sample * Short.MAX_VALUE);
                        pcm[i * 2] = (byte) (value & 0xff);
                        pcm[i * 2 + 1] = (byte) ((value >> 8) & 0xff);
                    }
                    line.write(pcm, 0, pcm.length);
                }
                line.drain();
            } catch (Exception ignored) {
                // Audio may be unavailable on some computers; the game remains playable.
            }
        }, "MemoryFog-Sound-" + kind);
        soundThread.setDaemon(true);
        soundThread.start();
    }

    private void loadProgress() {
        if (!SAVE_FILE.isFile()) return;
        Properties saved = new Properties();
        try (FileInputStream input = new FileInputStream(SAVE_FILE)) {
            saved.load(input);
            coins = Math.max(0, Integer.parseInt(saved.getProperty("coins", "0")));
            // Level access is session-only: each fresh launch starts with Level 1 unlocked.
            highestUnlockedLevel = 1;
            level = 1;
            gameCompleted = false;
            magnifiers = Math.max(0, Integer.parseInt(saved.getProperty("magnifiers", "0")));
            hints = Math.max(0, Integer.parseInt(saved.getProperty("hints", "0")));
            shields = Math.max(0, Integer.parseInt(saved.getProperty("shields",
                saved.getProperty("blowguns", "0"))));
            shieldArmed = Boolean.parseBoolean(saved.getProperty("shieldArmed", "false"));
            timerBoosts = Math.max(0, Integer.parseInt(saved.getProperty("timerBoosts", "0")));
            selectedCardBack = Math.max(0, Math.min(CARD_BACK_SKINS.length - 1,
                Integer.parseInt(saved.getProperty("selectedCardBack", "0"))));

            String[] unlocked = saved.getProperty("unlockedCardBacks", "1,0,0,0").split(",");
            for (int i = 0; i < Math.min(unlocked.length, unlockedCardBacks.length); i++) {
                unlockedCardBacks[i] = "1".equals(unlocked[i]);
            }
            unlockedCardBacks[0] = true;

            String[] savedStars = saved.getProperty("stars", "").split(",");
            for (int i = 0; i < Math.min(savedStars.length, starsByLevel.length); i++) {
                if (!savedStars[i].isEmpty()) {
                    starsByLevel[i] = Math.max(0, Math.min(3, Integer.parseInt(savedStars[i])));
                }
            }
            if (!unlockedCardBacks[selectedCardBack]) selectedCardBack = 0;
        } catch (Exception ex) {
            System.err.println("Could not load Squad Flip progress: " + ex.getMessage());
            level = 1;
            highestUnlockedLevel = 1;
            gameCompleted = false;
        }
    }

    private void saveProgress() {
        Properties saved = new Properties();
        saved.setProperty("coins", String.valueOf(coins));
        saved.setProperty("magnifiers", String.valueOf(magnifiers));
        saved.setProperty("hints", String.valueOf(hints));
        saved.setProperty("shields", String.valueOf(shields));
        saved.setProperty("shieldArmed", String.valueOf(shieldArmed));
        saved.setProperty("timerBoosts", String.valueOf(timerBoosts));
        saved.setProperty("selectedCardBack", String.valueOf(selectedCardBack));
        saved.setProperty("unlockedCardBacks", joinBooleans(unlockedCardBacks));
        saved.setProperty("stars", joinInts(starsByLevel));
        try (FileOutputStream output = new FileOutputStream(SAVE_FILE)) {
            saved.store(output, "Squad Flip saved progress");
        } catch (Exception ex) {
            System.err.println("Could not save Squad Flip progress: " + ex.getMessage());
        }
    }

    private String joinBooleans(boolean[] values) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) result.append(',');
            result.append(values[i] ? '1' : '0');
        }
        return result.toString();
    }

    private String joinInts(int[] values) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) result.append(',');
            result.append(values[i]);
        }
        return result.toString();
    }

    private void updateLabels() {
        String bestStars = starsByLevel[level] > 0 ? "   " + "★ ".repeat(starsByLevel[level]) : "";
        levelLabel.setText("Level " + level + bestStars + (isChallengeLevel() ? "  CHALLENGE" : ""));
        moneyLabel.setText("🪙 " + coins);
        timerLabel.setText(String.format("⏱ %d:%02d", secondsLeft / 60, secondsLeft % 60));
        inventoryLabel.setText("In your bag: 🔍 " + magnifiers + "   💡 " + hints
            + "   🛡 " + shields + (shieldArmed ? " (armed)" : "") + "   ⏱ " + timerBoosts);
        magnifyButton.setText(magnifierActive
            ? "🔍 X-Ray (" + magnifierSeconds + "s)"
            : "🔍 Magnify (" + magnifiers + ")");
        hintButton.setText("💡 Hint (" + hints + ")");
        shieldButton.setText(shieldArmed
            ? "🛡 Armed" : "🛡 Shield (" + shields + ")");
        timerButton.setText("⏱ +60 sec (" + timerBoosts + ")");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MemoryFogGame::new);
    }
}
